<section class="dashboard-counts no-padding-bottom" id="app">
    <div class="container-fluid">
        <div class="row bg-white has-shadow">
            <!-- Item -->
            <div class="col-xl-3 col-sm-6">
                <div class="item d-flex align-items-center">
                    <div class="icon bg-violet"><i class="icon-user"></i></div>
                    <div class="title"><span>Clippings</span>
                        
                            
                        
                    </div>
                    <div class="number"><strong>{{ clippings.length }}</strong></div>
                </div>
            </div>
            <!-- Item -->
            <div class="col-xl-3 col-sm-6">
                <div class="item d-flex align-items-center">
                    <div class="icon bg-red"><i class="icon-padnote"></i></div>
                    <div class="title"><span>Tweets</span>
                        
                            
                        
                    </div>
                    <div class="number"><strong>{{ tweets.length }}</strong></div>
                </div>
            </div>
            <!-- Item -->
            <div class="col-xl-3 col-sm-6">
                <div class="item d-flex align-items-center">
                    <div class="icon bg-green"><i class="icon-bill"></i></div>
                    <div class="title"><span>Videos</span>
                        
                            
                        
                    </div>
                    <div class="number"><strong>{{ videos.length }}</strong></div>
                </div>
            </div>
            <!-- Item -->
            <div class="col-xl-3 col-sm-6">
                <div class="item d-flex align-items-center">
                    <div class="icon bg-orange"><i class="icon-check"></i></div>
                    <div class="title"><span>Posts</span>
                        
                            
                        
                    </div>
                    <div class="number"><strong>{{ posts.length }}</strong></div>
                </div>
            </div>
        </div>
    </div>
</section>