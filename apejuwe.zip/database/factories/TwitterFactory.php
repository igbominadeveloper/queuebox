<?php

use Faker\Generator as Faker;

$factory->define(App\Twitter::class, function (Faker $faker) {
    return [
        //
    ];
});
